package nxt;

import nxt.db.DbClause;
import nxt.db.DbIterator;
import nxt.db.DbKey;
import nxt.db.EntityDbTable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.simple.JSONObject;
import java.io.StringWriter;
import java.io.IOException;

//Anil

public final class AssetPoll {

  static long ad;
  static long pd;


  private static final DbKey.LongKeyFactory<AssetPoll> pollDbKeyFactory = new DbKey.LongKeyFactory<AssetPoll>("id") {
      @Override
      public DbKey newKey(AssetPoll assetpoll) {
          return assetpoll.dbKey;
      }
  };

  private final static EntityDbTable<AssetPoll> pollTable = new EntityDbTable<AssetPoll>("assetpoll", pollDbKeyFactory, "name,description") {

      @Override
      protected AssetPoll load(Connection con, ResultSet rs, DbKey dbKey) throws SQLException {
          return new AssetPoll(rs, dbKey);
      }

      @Override
      protected void save(Connection con, AssetPoll assetpoll) throws SQLException {
          assetpoll.save(con);
      }
  };
  public static void data(JSONObject json) throws IOException
  {
    StringWriter out = new StringWriter();
      json.writeJSONString(out);

      String jsonText = out.toString();
      System.out.print(jsonText);
      System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
  }
  public static void safe(String assetid,String pollid,int size) {
    //Anil  SortedMap<String, Long> snapshotMap = new TreeMap<>();


      try (Connection con = Db.db.getConnection();
           PreparedStatement pstmt = con.prepareStatement("SELECT account_id, quantity FROM account_asset")) {

          try (ResultSet rs = pstmt.executeQuery()) {
              while (rs.next()) {
                  long accountId = rs.getLong("account_id");
                  long balance = rs.getLong("quantity");
                  System.out.println("acccccccccccccccccc"+accountId+"          "+balance);
              }
          }
      } catch (SQLException e) {
          throw new RuntimeException(e.getMessage(), e);
      }
      try (Connection con = Db.db.getConnection();
           PreparedStatement pstmt = con.prepareStatement("INSERT INTO voting_count  "
                   + "(asset_id, poll_id,count) "
                   + "VALUES (?, ?,?)")) {
                          int i = 0;
                          //ad=Long.parseLong(assetid);
                          //pd=Long.parseLong(pollid);
                          pstmt.setString(++i,assetid);
                          pstmt.setString(++i,pollid);
                          pstmt.setInt(++i,size);//Long.parseLong(pd)
                          int t=pstmt.executeUpdate();
                          System.out.println("acccccccccccccccccc3"+assetid+" ppppppppppppppddddd  "+pollid+"rrrrr"+t);

          try (ResultSet rs = pstmt.executeQuery()) {
              while (rs.next()) {
                  long accountId = rs.getLong("account_id");
                  long balance = rs.getLong("quantity");
                  System.out.println("acccccccccccccccccc"+accountId+"          "+balance);
              }
          }
      } catch (SQLException e) {
          throw new RuntimeException(e.getMessage(), e);
      }

    }
    public static void saveCount(String pollid,int count)
    {
      System.out.println("acccccccccccccccccc"+pollid+"          "+count);
      try (Connection con = Db.db.getConnection();
          PreparedStatement pstmt = con.prepareStatement("UPDATE voting_count SET count = ? WHERE poll_id = ?")) {
          pstmt.setInt(1, count);
          pstmt.setString(2,pollid);
          pstmt.executeUpdate();
      }
      catch (SQLException e) {
          throw new RuntimeException(e.getMessage(), e);
      }
    }
    public static int getCount(String assetid)
    {
      int count=0;

      try (Connection con = Db.db.getConnection();
           PreparedStatement pstmt = con.prepareStatement("SELECT count FROM voting_count WHERE asset_id=?")) {

             pstmt.setString(1,assetid);
             try (ResultSet rs = pstmt.executeQuery()) {
               if(rs.next()){
                   count = rs.getInt("count");
               }


             }
      } catch (SQLException e) {
          throw new RuntimeException(e.getMessage(), e);
      }
      return count;
    }

  static void init() {}

    private  final long assetid;
    private  final DbKey dbKey;
    private  final long pollid;

  // private Asset(Transaction transaction, Attachment.ColoredCoinsAssetIssuance attachment) {
  //     this.assetId = transaction.getId();
  //     this.dbKey = assetDbKeyFactory.newKey(this.assetId);
  //     this.accountId = transaction.getSenderId();
  //     this.name = attachment.getName();
  //     this.description = attachment.getDescription();
  //     this.quantityQNT = attachment.getQuantityQNT();
  //     this.initialQuantityQNT = this.quantityQNT;
  //     this.decimals = attachment.getDecimals();
  // }

  private AssetPoll(ResultSet rs, DbKey dbKey) throws SQLException {
      this.assetid = rs.getLong("assetid");
      this.dbKey = dbKey;
      this.pollid = rs.getLong("poll_id");

  }

  private void save(Connection con) throws SQLException {
    try (PreparedStatement pstmt = con.prepareStatement("INSERT INTO voting_count "
            + "(asset_id, poll_id,count) "
            + "VALUES (?, ?,0)")) {
        int i = 0;
        pstmt.setLong(++i,assetid);
        pstmt.setLong(++i,pollid);
        pstmt.executeUpdate();
    }

  }

  public long getPollId() {
      return pollid;
  }

  public long getAseetId() {
      return assetid;
  }
}
